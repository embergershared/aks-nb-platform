#!/bin/bash

############################################
# Delete custom-values.yaml
############################################
rm custom-values.yaml